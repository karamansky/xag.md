<?php
namespace MikadoCore\CPT\Shortcodes\CenteredSlider;

use MikadoCore\Lib;

class CenteredSlider implements Lib\ShortcodeInterface {

    private $base;

    /**
     * Image Gallery constructor.
     */
    public function __construct()
    {
        $this->base = 'mkdf_centered_slider';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    /**
     * Returns base for shortcode
     * @return string
     */
    public function getBase()
    {
        return $this->base;
    }

    /**
     * Maps shortcode to Visual Composer. Hooked on vc_before_init
     *
     * @see mkd_core_get_carousel_slider_array_vc()
     */
    public function vcMap()
    {

        vc_map(array(
            'name' => esc_html__('Centered Slider', 'mkdf-core'),
            'base' => $this->base,
            'category' => esc_html__('by MIKADO', 'mkdf-core'),
            'icon' => 'icon-wpb-centered-slider extended-custom-icon',
            'allowed_container_element' => 'vc_row',
            'params' => array(
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Items', 'mkdf-core'),
                    'param_name' => 'slider_items',
                    'value' => '',
                    'params' => array(
                        array(
                            'type' => 'attach_image',
                            'param_name' => 'image',
                            'heading' => esc_html__('Image', 'mkdf-core'),
                            'description' => esc_html__('Select image from media library', 'mkdf-core')
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'video_link',
                            'heading' => esc_html__('Video Link', 'mkdf-core'),
                            'description' => esc_html__('Add video link that can be opened in pretty photo', 'mkdf-core')
                        ),
                    )
                ),
                array(
                    'type'        => 'attach_image',
                    'param_name'  => 'play_button_image',
                    'heading'     => esc_html__( 'Play Button Custom Image', 'mkdf-core' ),
                    'description' => esc_html__( 'Select image from media library. If you use this field then play button color and button size options will not work', 'mkdf-core' )
                )
            )
        ));

    }

    /**
     * Renders shortcodes HTML
     *
     * @param $atts array of shortcode params
     * @param $content string shortcode content
     *
     * @return string
     */
    public function render($atts, $content = null)
    {

        $args = array(
            'slider_items'      => '',
            'play_button_image' => ''
        );

        $params = shortcode_atts($args, $atts);

        $params['slider_items'] = vc_param_group_parse_atts($atts['slider_items']);


        return mkdf_core_get_shortcode_module_template_part('templates/centered-slider-template', 'centered-slider', '', $params);

    }
}