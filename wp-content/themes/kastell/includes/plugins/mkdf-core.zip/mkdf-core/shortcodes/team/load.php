<?php
include_once MIKADO_CORE_SHORTCODES_PATH.'/team/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/team/team-list.php';