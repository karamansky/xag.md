<div class="mkdf-project-info-item mkdf-item-space <?php echo esc_attr($holder_classes); ?>">
    <div class="mkdf-pi-inner">
        <h2 class="mkdf-pi-title"> <?php echo esc_html($project_info_title); ?> </h2>
        <div class="mkdf-pi-text">
            <?php echo esc_html($project_info_text); ?>
        </div>
    </div>
</div>