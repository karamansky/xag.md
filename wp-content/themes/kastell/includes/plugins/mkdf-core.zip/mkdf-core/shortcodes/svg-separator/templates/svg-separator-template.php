<?php $randomize = rand(1, 1000); ?>
<div <?php kastell_mkdf_class_attribute($separator_classes); ?>>
    <div class="mkdf-svg-separator mkdf-svg-frames-class" <?php echo kastell_mkdf_get_inline_attrs($separator_data); ?> >
        <svg version="1.1" <?php echo kastell_mkdf_get_inline_style($color); ?> id="<?php echo 'layer_' . $randomize; ?>" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
             width="65.167px" height="11.917px" viewBox="0 0 65.167 11.917" enable-background="new 0 0 65.167 11.917" xml:space="preserve">
            <path fill="none" stroke="#010101" stroke-width="1" stroke-miterlimit="3" d="M1.045,9.833 9.295,2.083 17.295,9.833
            24.295,2.083 32.291,9.833 39.294,2.083 47.294,9.833 54.294,2.083 64.287,9.833 "/>
        </svg>
    </div>
</div>