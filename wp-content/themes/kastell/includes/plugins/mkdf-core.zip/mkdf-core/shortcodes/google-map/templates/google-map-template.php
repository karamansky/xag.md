<div class="mkdf-google-map-holder <?php echo esc_attr($map_holder_classes) ?>">
    <div class="mkdf-google-map" id="<?php echo esc_attr($map_id); ?>" <?php echo kastell_mikado_get_module_part( $map_data ); ?>></div>
    <?php if ($scroll_wheel == "false") { ?>
        <div class="mkdf-google-map-overlay"></div>
    <?php } ?>
</div>
