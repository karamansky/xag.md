<?php
$tab_data_str = '';
$icon_html = '';
$tab_data_str .= 'data-icon-pack="'.$icon_pack.'" ';
$icon_html .= (empty($custom_icon))  ? kastell_mkdf_execute_shortcode('mkdf_icon', $icon_parameters) : wp_get_attachment_image($custom_icon, 'full');
$tab_data_str .= 'data-icon-html="'. esc_attr($icon_html) .'"';
?>
<div class="mkdf-icon-tab-container" id="tab-<?php echo sanitize_title($tab_title); ?>" <?php echo kastell_mikado_get_module_part( $tab_data_str ); ?>>
    <div class="mkdf-icon-tab-content">
        <div class="mkdf-icon-tab-content-inner">
            <?php echo do_shortcode($content); ?>
        </div>
        <div class="mkdf-icon-tab-image">
            <?php echo wp_get_attachment_image($content_image, 'full'); ?>
        </div>
    </div>
</div>