<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/project-info/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/project-info/project-info-item.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/project-info/project-info.php';