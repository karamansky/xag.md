<?php
namespace MikadoCore\CPT\Shortcodes\ProjectInfo;

use MikadoCore\Lib;

class ProjectInfoItem implements Lib\ShortcodeInterface {
	private $base;
	
	function __construct() {
		$this->base = 'mkdf_project_info_item';
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Mikado Project Info Item', 'mkdf-core' ),
					'base'                      => $this->base,
					'icon'                      => 'icon-wpb-project-info-item extended-custom-icon',
					'category'                  => esc_html__( 'by MIKADO', 'mkdf-core' ),
					'allowed_container_element' => 'vc_row',
					'as_child'                  => array( 'only' => 'mkdf_project_info' ),
					'params'                    => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'custom_class',
							'heading'     => esc_html__( 'Custom CSS Class', 'mkdf-core' ),
							'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'mkdf-core' )
						),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'project_info_title',
                            'heading'     => esc_html__( 'Project Info Title', 'mkdf-core' ),
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'project_info_text',
                            'heading'     => esc_html__( 'Project Info Text', 'mkdf-core' ),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'enable_separator',
                            'heading'     => esc_html__( 'Enable Right Separator', 'mkdf-core' ),
                            'value'       => array_flip(kastell_mkdf_get_yes_no_select_array(false))
                        ),
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'custom_class'             => '',
			'project_info_title'       => '',
			'project_info_text'        => '',
            'enable_separator'          => 'no'
		);
		$params = shortcode_atts( $args, $atts );
		
		$params['holder_classes'] = $this->getHolderClasses( $params );
		
		$html = mkdf_core_get_shortcode_module_template_part( 'templates/project-info-template', 'project-info', '', $params );
		
		return $html;
	}
	
	private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		$holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
		$holderClasses[] = $params['enable_separator'] == 'yes' ? 'mkdf-pii-separator-enabled' : '';

		return implode( ' ', $holderClasses );
	}


}