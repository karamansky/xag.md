<div <?php kastell_mkdf_class_attribute($holder_classes); ?>>
    <div
        class="mkdf-team-slider mkdf-owl-slider" <?php echo kastell_mkdf_get_inline_attrs($data_attrs); ?>>
        <?php echo do_shortcode($content); ?>
    </div>
</div>