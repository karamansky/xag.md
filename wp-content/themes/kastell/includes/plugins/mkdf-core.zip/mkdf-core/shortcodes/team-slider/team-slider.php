<?php

namespace MikadoCore\CPT\Shortcodes\TeamSlider;

use MikadoCore\Lib;

class TeamSlider implements Lib\ShortcodeInterface {
    private $base;

    public function __construct() {
        $this->base = 'mkdf_team_slider';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        vc_map(array(
            'name'         => 'Mikado Team Slider',
            'base'         => $this->base,
            'category'     => esc_html__('by MIKADO', 'mkdf-core'),
            'icon'         => 'icon-wpb-team-slider extended-custom-icon',
            'is_container' => true,
            'js_view'      => 'VcColumnView',
            'as_parent'    => array('only' => 'mkdf_team_slider_item'),
            'params'       => array(
                array(
                    'type'        => 'dropdown',
                    'param_name'  => 'number_of_items',
                    'heading'     => esc_html__( 'Number Of Visible Items', 'mkdf-core' ),
                    'value'       => array(
                        esc_html__( 'One', 'mkdf-core' )   => '1',
                        esc_html__( 'Two', 'mkdf-core' )   => '2',
                        esc_html__( 'Three', 'mkdf-core' ) => '3',
                        esc_html__( 'Four', 'mkdf-core' )  => '4',
                        esc_html__( 'Five', 'mkdf-core' )  => '5',
                        esc_html__( 'Six', 'mkdf-core' )   => '6'
                    ),
                    'save_always' => true,
                    'dependency'  => Array( 'element' => 'type', 'value' => 'boxed' ),
                ),
                array(
                    'type'        => 'dropdown',
                    'param_name'  => 'space_between_items',
                    'heading'     => esc_html__( 'Space Between Items', 'mkdf-core' ),
                    'value'       => array_flip( kastell_mkdf_get_space_between_items_array() ),
                    'save_always' => true
                ),
                array(
                    'type'        => 'dropdown',
                    'param_name'  => 'slider_loop',
                    'heading'     => esc_html__( 'Enable Slider Loop', 'mkdf-core' ),
                    'value'       => array_flip( kastell_mkdf_get_yes_no_select_array( false, true ) ),
                    'save_always' => true,
                ),
                array(
                    'type'        => 'dropdown',
                    'param_name'  => 'slider_autoplay',
                    'heading'     => esc_html__( 'Enable Slider Autoplay', 'mkdf-core' ),
                    'value'       => array_flip( kastell_mkdf_get_yes_no_select_array( false, true ) ),
                    'save_always' => true,
                ),
                array(
                    'type'        => 'textfield',
                    'param_name'  => 'slider_speed',
                    'heading'     => esc_html__( 'Slide Duration', 'mkdf-core' ),
                    'description' => esc_html__( 'Default value is 5000 (ms)', 'mkdf-core' ),
                ),
                array(
                    'type'        => 'textfield',
                    'param_name'  => 'slider_speed_animation',
                    'heading'     => esc_html__( 'Slide Animation Duration', 'mkdf-core' ),
                    'description' => esc_html__( 'Speed of slide animation in milliseconds. Default value is 600.', 'mkdf-core' ),
                ),
                array(
                    'type'        => 'dropdown',
                    'param_name'  => 'slider_navigation',
                    'heading'     => esc_html__( 'Enable Slider Navigation Arrows', 'mkdf-core' ),
                    'value'       => array_flip( kastell_mkdf_get_yes_no_select_array( false, true ) ),
                    'save_always' => true,
                ),
                array(
                    'type'        => 'dropdown',
                    'param_name'  => 'slider_pagination',
                    'heading'     => esc_html__( 'Enable Slider Pagination', 'mkdf-core' ),
                    'value'       => array_flip( kastell_mkdf_get_yes_no_select_array( false, true ) ),
                    'save_always' => true,
                )
            )
        ));
    }

    public function render($atts, $content = null) {
        $default_atts = array(
            'number_of_items'         => '3',
            'space_between_items'     => 'normal',
            'slider_loop'             => 'yes',
            'slider_autoplay'         => 'yes',
            'slider_speed'            => '5000',
            'slider_speed_animation'  => '600',
            'slider_navigation'       => 'yes',
            'slider_pagination'       => 'yes'

        );

        $params = shortcode_atts($default_atts, $atts);

        /* proceed slider type parameter to nested shortcode in order to call proper template */
        $params['content'] = preg_replace('/\[mkdf_team_slider_item\b/i', '[mkdf_team_slider_item slider_type="simple"', $content);

        $params['holder_classes'] = $this->getHolderClasses($params, $default_atts);
        $params['data_attrs']     = $this->getDataAttribute($params);

        return mkdf_core_get_shortcode_module_template_part('templates/team-slider-template', 'team-slider', '', $params);
    }

    /**
     * Returns array of holder classes
     *
     * @param $params
     *
     * @return array
     */
    private function getHolderClasses($params, $default_atts) {
        $classes = array('mkdf-team-slider-holder');

        $classes[] = 'simple';
        $classes[] = ! empty( $params['space_between_items'] ) ? 'mkdf-' . $params['space_between_items'] . '-space' : 'mkdf-' . $default_atts['space_between_items'] . '-space';

        return $classes;
    }


    /**
     * Return Team Slider data attribute
     *
     * @param $params
     *
     * @return string
     */

    private function getDataAttribute($params) {

        $slider_data = array();

        if($params['number_of_items'] !== '') {
            $slider_data['data-number-of-items'] = $params['number_of_items'];
        }

        $slider_data['data-enable-loop']            = ! empty( $params['slider_loop'] ) ? $params['slider_loop'] : '';
        $slider_data['data-enable-autoplay']        = ! empty( $params['slider_autoplay'] ) ? $params['slider_autoplay'] : '';
        $slider_data['data-slider-speed']           = ! empty( $params['slider_speed'] ) ? $params['slider_speed'] : '5000';
        $slider_data['data-slider-speed-animation'] = ! empty( $params['slider_speed_animation'] ) ? $params['slider_speed_animation'] : '600';
        $slider_data['data-enable-navigation']      = ! empty( $params['slider_navigation'] ) ? $params['slider_navigation'] : '';
        $slider_data['data-enable-pagination']      = ! empty( $params['slider_pagination'] ) ? $params['slider_pagination'] : '';
        $slider_data['data-slider-margin']          = 'no';

        return $slider_data;
    }
}