<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/centered-slider/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/centered-slider/centered-slider.php';
