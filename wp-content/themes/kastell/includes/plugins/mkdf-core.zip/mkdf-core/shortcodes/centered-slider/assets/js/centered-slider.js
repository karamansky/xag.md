(function ($) {
    'use strict';

    var centeredSlider = {};
    mkdf.modules.centeredSlider = centeredSlider;

    centeredSlider.mkdfInitCenteredSlider = mkdfInitCenteredSlider;


    centeredSlider.mkdfOnDocumentReady = mkdfOnDocumentReady;

    $(document).ready(mkdfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function mkdfOnDocumentReady() {
        mkdfInitCenteredSlider();
    }

    function mkdfInitCenteredSlider() {
        var centeredSliders = $('.mkdf-centered-slider');

        var centerPadding = mkdf.windowWidth / 3 + 'px';

        if (centeredSliders.length) {
            centeredSliders.each(function () {
                var thisSlider = $(this);

                if (thisSlider.width() >= mkdf.windowWidth) {
                    thisSlider.on('init', function () {
                        // change default opacity on init
                        $(this).addClass('full-width');
                        thisSlider.css({'opacity': '1'});
                    }).slick({
                        infinite: true,
                        autoplay: true,
                        autoplaySpeed: 4000,
                        dots: false,
                        arrows: false,
                        centerMode: true,
                        centerPadding: centerPadding,
                        slidesToShow: 1,
                        speed: 1000,
                        fade: false,
                        touchThreshold: 120,
                        cssEase: 'cubic-bezier(0.1, 0.7, 0.1, 1)',
                        responsive: [
                            {
                                breakpoint: 1025,
                                settings: {
                                    centerMode: true,
                                    slidesToShow: 1,
                                    autoplay: true
                                }
                            },
                            {
                                breakpoint: 769,
                                settings: {
                                    centerMode: false,
                                    slidesToShow: 1,
                                    autoplay: true
                                }
                            },
                            {
                                breakpoint: 481,
                                settings: {
                                    centerMode: false,
                                    slidesToShow: 1,
                                    autoplay: true
                                }
                            }]
                    });

                    thisSlider.find('.slick-center').css({"transform": "scale(1.5) translateZ(0)", "z-index": "11"});

                    thisSlider.on('beforeChange', function () {
                        $(this).find('.slick-center').css({"transform": "scale(1) translateZ(0)", "z-index": "10"});
                    });

                    thisSlider.on('afterChange', function () {
                        $(this).find('.slick-center').css({"transform": "scale(1.5) translateZ(0)", "z-index": "11"});
                    });
                }
                else {
                    thisSlider.on('init', function () {
                        // change default opacity on init
                        thisSlider.css({'opacity': '1'});
                    }).slick({
                        infinite: true,
                        autoplay: true,
                        autoplaySpeed: 3000,
                        dots: false,
                        arrows: false,
                        centerMode: false,
                        centerPadding: centerPadding,
                        slidesToShow: 1,
                        speed: 1000,
                        fade: false,
                        cssEase: 'cubic-bezier(0.1, 0.7, 0.1, 1)'
                    });
                }
            });
        }
    }

})(jQuery);