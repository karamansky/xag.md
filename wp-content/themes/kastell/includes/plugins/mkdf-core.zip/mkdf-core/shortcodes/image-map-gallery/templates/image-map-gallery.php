<div class="mkdf-image-map-gallery mkdf-grid-row<?php echo esc_attr($holder_classes); ?> " data-image-map-name='<?php echo esc_attr($image_map_name); ?>'>
    <div class="mkdf-img-holder mkdf-grid-col-6">
        <div class="mkdf-img-section mkdf-img-holder-inner active">
            <div class="mkdf-img-slider" <?php echo kastell_mkdf_get_inline_attrs($slider_data); ?>>
                <?php foreach ($images as $image) { ?>
                    <div class="mkdf-ig-image" data-imp-shape="<?php echo esc_attr($image['image_shape']); ?>">
                        <?php if(is_array($image_size) && count($image_size)) :
                            echo kastell_mkdf_generate_thumbnail($image['image_id'], null, $image_size[0], $image_size[1]);
                        else:
                            echo wp_get_attachment_image($image['image_id'], $image_size);
                        endif; ?>
                    </div>
                <?php } ?>
            </div>
            <ul id="mkdf-imp-pagination" class="mkdf-pagination-slider clearfix">
                <?php foreach ($images as $image) { ?>
                    <li class="mkdf-impp-item"><?php echo wp_get_attachment_image($image['image_id'], 'full') ?></li>
                <?php } ?>
            </ul>
        </div>
        <?php if(!empty($video_link)) { ?>
            <div class="mkdf-img-section mkdf-img-video-inner">
                <?php echo kastell_mkdf_execute_shortcode('mkdf_video_button', array(
                    'video_link' => $video_link,
                    'video_image'=> $video_image
                )) ?>
            </div>
        <?php } ?>
        <?php if(!empty($video_link_360)) { ?>
            <div class="mkdf-img-section mkdf-img-360-video-inner">
                <?php echo kastell_mkdf_execute_shortcode('mkdf_video_button', array(
                    'video_link' => $video_link_360,
                    'video_image'=> $video_image_360
                )) ?>
            </div>
        <?php } ?>
    </div>
    <div class="mkdf-map-holder mkdf-grid-col-4">
        <?php if( !empty($video_link) || !empty($video_link_360)) { ?>
            <ul class="mkdf-map-navigation">
                <li class="mkdf-map-nav-item mkdf-active-map active">
                    <span class="mkdf-map-nav-item-icon dripicons-photo"></span>
                    <span class="mkdf-map-nav-item-text"><?php echo esc_html__('Photos', 'mkdf-core') ?></span>
                </li>
                <?php if(!empty($video_link)) { ?>
                    <li class="mkdf-map-nav-item mkdf-inactive-map">
                        <span class="mkdf-map-nav-item-icon dripicons-camcorder"></span>
                        <span class="mkdf-map-nav-item-text"><?php echo esc_html__('Video', 'mkdf-core') ?></span>
                    </li>
                <?php } ?>
                <?php if(!empty($video_link_360)) { ?>
                    <li class="mkdf-map-nav-item mkdf-inactive-map">
                        <span class="mkdf-map-nav-item-icon dripicons-clockwise"></span>
                        <span class="mkdf-map-nav-item-text"><?php echo esc_html__('360 Video', 'mkdf-core') ?></span>
                    </li>
                <?php } ?>
            </ul>
        <?php } ?>
        <div class="mkdf-image-map-holder">
            <?php echo do_shortcode($image_map_shortcode); ?>
            <div class="mkdf-image-map-holder-overlay"></div>
        </div>
    </div>
</div>
