<div class="mkdf-centered-slider">
    <?php foreach ($slider_items as $item) : ?>
        <div class="mkdf-slider-item">
            <?php echo wp_get_attachment_image($item['image'], 'kastell_mkdf_landscape');
            if (!empty($item['video_link'])) :?>
                <a class="mkdf-video-link" href="<?php echo esc_url($item['video_link']) ?>" data-rel="prettyPhoto[single_pretty_photo]">
                    <?php if(!empty($play_button_image)) {
                        echo wp_get_attachment_image($play_button_image, 'full');
                    }
                     else { ?>
                         <span class="mkdf-video-button-play">
						    <span class="mkdf-video-icon-play dripicons-media-play"></span>
					    </span>
                     <?php } ?>
                </a>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>