<?php
namespace MikadoCore\CPT\Shortcodes\IconTabs;

use MikadoCore\Lib;

class IconTabsItem implements Lib\ShortcodeInterface {
	private $base;
	
	function __construct() {
		$this->base = 'mkdf_icon_tabs_item';
		add_action('vc_before_init', array($this, 'vcMap'));
	}
	
	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'            => esc_html__( 'Mikado Icon Tabs Item', 'mkdf-core' ),
					'base'            => $this->getBase(),
					'as_parent'       => array( 'except' => 'vc_row' ),
					'as_child'        => array( 'only' => 'mkdf_icon_tabs' ),
					'category'        => esc_html__( 'by MIKADO', 'mkdf-core' ),
					'icon'            => 'icon-wpb-icon-tabs-item extended-custom-icon',
					'content_element' => true,
					'js_view'         => 'VcColumnView',
					'params'          => array_merge(
						array(
							array(
								'type'       => 'textfield',
								'param_name' => 'tab_title',
								'heading'    => esc_html__( 'Title', 'mkdf-core' )
							)
						),
						kastell_mkdf_icon_collections()->getVCParamsArray(),
						array(
							array(
								'type'       => 'attach_image',
								'param_name' => 'custom_icon',
								'heading'    => esc_html__( 'Custom Icon', 'mkdf-core' )
							),
							array(
								'type'        => 'textfield',
								'param_name'  => 'custom_icon_size',
								'heading'     => esc_html__( 'Custom Icon Size (px)', 'mkdf-core' ),
								'description' => esc_html__( 'Enter the value in px, default value is 16px', 'mkdf-core' ),
								'group'       => esc_html__( 'Icon Settings', 'mkdf-core' )
							),
                            array(
                                'type'       => 'attach_image',
                                'param_name' => 'content_image',
                                'heading'    => esc_html__( 'Content Image', 'mkdf-core' )
                            ),
							array(
								'type'       => 'dropdown',
								'param_name' => 'icon_animation',
								'heading'    => esc_html__( 'Icon Animation', 'mkdf-core' ),
								'value'      => array_flip( kastell_mkdf_get_yes_no_select_array( false ) ),
								'group'      => esc_html__( 'Icon Settings', 'mkdf-core' )
							),
							array(
								'type'       => 'textfield',
								'param_name' => 'icon_animation_delay',
								'heading'    => esc_html__( 'Icon Animation Delay (ms)', 'mkdf-core' ),
								'dependency' => array( 'element' => 'icon_animation', 'value' => array( 'yes' ) ),
								'group'      => esc_html__( 'Icon Settings', 'mkdf-core' )
							),
						)
					)
				)
			);
		}
	}

	public function render($atts, $content = null) {
		$default_atts = array(
			'tab_title' 	   			  => 'Tab',
			'icon_type'                   => 'mkdf-normal',
			'icon_size'                   => 'mkdf-icon-medium',
			'custom_icon_size'            => '16px',
			'content_image'               => '',
			'icon_animation'              => '',
			'icon_animation_delay'        => '',
		);

		$default_atts = array_merge($default_atts, kastell_mkdf_icon_collections()->getShortcodeParams());
		$params       = shortcode_atts($default_atts, $atts);
		extract($params);

		$rand_number = rand(0, 1000);

		$params['tab_title'] = $params['tab_title'].'-'.$rand_number;
		$params['icon_parameters'] = $this->getIconParameters($params);


		$params['content'] = $content;
		
		$output = '';


		$output .= mkdf_core_get_shortcode_module_template_part('templates/icon-tab-content','icon-tabs', '', $params);
		
		return $output;
	}

	/**
	 * Returns parameters for icon shortcode as a string
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getIconParameters($params) {
		$params_array = array();

		if(empty($params['custom_icon'])) {
			$iconPackName = kastell_mkdf_icon_collections()->getIconCollectionParamNameByKey($params['icon_pack']);

			$params_array['icon_pack']   = $params['icon_pack'];
			$params_array[$iconPackName] = $params[$iconPackName];

			if(!empty($params['icon_size'])) {
				$params_array['size'] = $params['icon_size'];
			}

			if(!empty($params['custom_icon_size'])) {
				$params_array['custom_size'] = kastell_mkdf_filter_px($params['custom_icon_size']).'px';
			}

			if(!empty($params['icon_type'])) {
				$params_array['type'] = $params['icon_type'];
			}

			$params_array['icon_animation']       = $params['icon_animation'];
			$params_array['icon_animation_delay'] = $params['icon_animation_delay'];
		}

		return $params_array;
	}
}