(function($) {
	'use strict';
	
	var svgSeparator = {};
	mkdf.modules.svgSeparator = svgSeparator;
	
	svgSeparator.mkdfInitSvgSeparators = mkdfInitSvgSeparators;
	
	
	svgSeparator.mkdfOnDocumentReady = mkdfOnDocumentReady;
	
	$(document).ready(mkdfOnDocumentReady);
	
	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function mkdfOnDocumentReady() {
		mkdfInitSvgSeparators();
	}
	
	/*
	 **	Horizontal progress bars shortcode
	 */
	function mkdfInitSvgSeparators(){
        if($('.mkdf-svg-separator').length && $('.mkdf-no-animations-on-touch').length === 0){
            $('.mkdf-svg-separator').each(function(){
                var separator = $(this);
                separator.appear(function() {
                    separator.addClass('mkdf-svg-separator-on');
                },{accX: 0, accY: mkdfGlobalVars.vars.mkdfElementAppearAmount});
            });
        }
	}
	
})(jQuery);