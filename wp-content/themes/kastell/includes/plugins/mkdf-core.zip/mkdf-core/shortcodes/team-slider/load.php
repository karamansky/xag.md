<?php
include_once MIKADO_CORE_SHORTCODES_PATH.'/team-slider/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/team-slider/team-slider.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/team-slider/team-slider-item.php';