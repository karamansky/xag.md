<?php if(kastell_mkdf_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>