<?php

require_once 'property-info.php';
require_once 'helper-functions.php';