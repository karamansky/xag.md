<?php $categories = wp_get_post_terms($selected_project, 'property-category'); ?>

<div class="mkdf-property-info-text-holder <?php echo esc_attr($holder_classes); ?>">
    <?php
    if($query_results->have_posts()):
        while ( $query_results->have_posts() ) : $query_results->the_post();
            ?>
            <div class="mkdf-property-info-text-item">
                <div class="mkdf-pit-main-content">
                    <div class="mkdf-pit-category-holder">
                        <?php echo kastell_mkdf_execute_shortcode('mkdf_svg_separator', array()); ?>
                            <?php foreach ($categories as $cat) { ?>
                                <a itemprop="url" class="mkdf-pit-category" href="<?php echo esc_url(get_term_link($cat->term_id)); ?>"><?php echo esc_html($cat->name); ?></a>
                            <?php } ?>
                        <?php echo kastell_mkdf_execute_shortcode('mkdf_svg_separator', array()); ?>
                    </div>
                    <div class="mkdf-pit-title-holder">
                        <<?php echo esc_attr($title_tag); ?> itemprop="name" class="mkdf-pit-title entry-title" <?php kastell_mkdf_inline_style($title_styles); ?>>
                            <?php echo esc_attr(get_the_title()); ?>
                        </<?php echo esc_attr($title_tag); ?>>
                    </div>
                </div>
            </div>
            <?php
        endwhile;
    else:
        echo mkdf_core_get_cpt_shortcode_module_template_part('property', 'property-info', 'parts/posts-not-found');
    endif;
    wp_reset_postdata();
    ?>
</div>
