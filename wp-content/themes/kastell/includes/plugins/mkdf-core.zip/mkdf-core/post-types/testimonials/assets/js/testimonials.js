(function($) {
	'use strict';

	var testimonials = {};
	mkdf.modules.accordions = testimonials;

	testimonials.mkdfInitTestimonials = mkdfInitTestimonials;


	testimonials.mkdfOnDocumentReady = mkdfOnDocumentReady;

	$(document).ready(mkdfOnDocumentReady);

	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function mkdfOnDocumentReady() {
		mkdfInitTestimonials();
	}

	/**
	 * Init accordions shortcode
	 */
	function mkdfInitTestimonials(){
		var testimonial = $('.mkdf-testimonials');
		if(testimonial.length) {
			testimonial.each(function() {

				var thisTestimonial = $(this);

				thisTestimonial.appear(function() {
					thisTestimonial.css('visibility', 'visible');
				}, {accX: 0, accY: mkdfGlobalVars.vars.mkdfElementAppearAmount});

				var controlNav = true;
				var directionNav = true;
				var autoplay = true;
				var interval = 5000;
				var items = 3;
				var type = '';
				if(typeof thisTestimonial.data('autoplay-timeout') !== 'undefined' && thisTestimonial.data('autoplay-timeout') !== false) {
					interval = thisTestimonial.data('autoplay-timeout') * 1000;
					if(interval === 0) {
						autoplay = false;
					}
				}
				if(typeof thisTestimonial.data('type') !== 'undefined' && thisTestimonial.data('type') !== '') {
					type = thisTestimonial.data('type');
				}
				if(typeof thisTestimonial.data('enable-navigation') !== 'undefined' && thisTestimonial.data('enable-navigation') !== '' && thisTestimonial.data('enable-navigation') === 'no') {
                    directionNav = false;
				}

                if(typeof thisTestimonial.data('enable-pagination') !== 'undefined' && thisTestimonial.data('enable-pagination') !== '' && thisTestimonial.data('enable-pagination') === 'no') {
                    controlNav = false;
                }

				if(typeof thisTestimonial.data('number-of-items') !== 'undefined' && thisTestimonial.data('number-of-items') !== '') {
					items = thisTestimonial.data('number-of-items');
				}
				//var iconClasses = getIconClassesForNavigation(directionNavArrowsTestimonials); TODO

				if(type === 'standard') {
					thisTestimonial.owlCarousel({
						items: 1,
						loop: true,
						autoplay: autoplay,
						autoplayTimeout: interval,
						mouseDrag: true,
						dots: controlNav,
						nav: directionNav,
						navText: [
							'<span class="mkdf-prev-icon"><i class="arrow_carrot-left"></i></span>',
							'<span class="mkdf-next-icon"><i class="arrow_carrot-right"></i></span>'
						]
					});
				}
				else if(type === 'boxed') {
					thisTestimonial.owlCarousel({
						items: 1 ,
						margin: 32,
						loop: true,
						autoplay: false,
						autoplayTimeout: interval,
						mouseDrag: false,
						dots: false,
						nav: false,
						navText: [
							'<span class="mkdf-prev-icon"><i class="fa fa-angle-left"></i></span>',
							'<span class="mkdf-next-icon"><i class="fa fa-angle-right"></i></span>'
						]
					});
				}
			});

			mkdf.modules.common.mkdfInitParallax();

		}
	}

})(jQuery);