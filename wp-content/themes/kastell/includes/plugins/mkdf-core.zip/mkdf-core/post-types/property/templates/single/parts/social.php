<?php if(kastell_mkdf_options()->getOptionValue('enable_social_share') == 'yes' && kastell_mkdf_options()->getOptionValue('enable_social_share_on_property-item') == 'yes') : ?>
    <div class="mkdf-ps-info-item mkdf-ps-social-share">
        <?php echo kastell_mkdf_get_social_share_html() ?>
    </div>
<?php endif; ?>