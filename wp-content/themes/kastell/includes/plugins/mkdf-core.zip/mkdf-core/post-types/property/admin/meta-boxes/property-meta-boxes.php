<?php

if ( ! function_exists( 'mkdf_core_map_property_meta' ) ) {
	function mkdf_core_map_property_meta() {
		global $kastell_mkdf_Framework;
		
		$mkd_pages = array();
		$pages      = get_pages();
		foreach ( $pages as $page ) {
			$mkd_pages[ $page->ID ] = $page->post_title;
		}
		
		//Property Additional Sidebar Items
		
		$mkdAdditionalSidebarItems = kastell_mkdf_create_meta_box(
			array(
				'scope' => array( 'property-item' ),
				'title' => esc_html__( 'Property Features', 'mkdf-core' ),
				'name'  => 'property_properties'
			)
		);
        
        kastell_mkdf_add_repeater_field(
            array(
                'name'        => 'mkdf_property_feature_repeater',
                'label'       => esc_html__('Property Features', 'mkdf-core'),
                'fields' => array(
                    array(
                        'name'        => 'mkdf_property_feature_image',
                        'type'        => 'image',
                        'label'       => esc_html__('Feature Image', 'mkdf-core'),
                    ),
                    array(
                        'name'        => 'mkdf_property_feature_title',
                        'type'        => 'text',
                        'label'       => esc_html__('Title', 'mkdf-core'),
                    ),
                    array(
                        'name'        => 'mkdf_property_feature_description',
                        'type'        => 'text',
                        'label'       => esc_html__('Description', 'mkdf-core'),
                    )

                ),
                'parent'      => $mkdAdditionalSidebarItems,
                'description' => ''
            )
        );
	}
	
	add_action( 'kastell_mkdf_meta_boxes_map', 'mkdf_core_map_property_meta', 40 );
}