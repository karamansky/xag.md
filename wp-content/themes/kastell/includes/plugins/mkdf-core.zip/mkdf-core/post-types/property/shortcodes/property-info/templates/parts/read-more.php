<div class="mkdf-pi-read-more">
    <?php
        echo kastell_mkdf_execute_shortcode('mkdf_button', array(
            'type'  => 'simple',
            'text'  => esc_html__('Read More', 'mkdf-core'),
            'link'  => get_the_permalink(),
            'fe_icon'   => 'arrow_carrot-2right',
            'icon_pack' => 'font_elegant'
        ));
    ?>
</div>