<div class="mkdf-full-width">
	<div class="mkdf-full-width-inner">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="mkdf-property-single-holder <?php echo esc_attr($holder_classes); ?>">
				<?php if(post_password_required()) {
					echo get_the_password_form();
				} else {
					do_action('kastell_mkdf_property_page_before_content');
					
					mkdf_core_get_cpt_single_module_template_part('templates/single/layout-collections/'.$item_layout, 'property', '', $params);
					
					do_action('kastell_mkdf_property_page_after_content');
					
					mkdf_core_get_cpt_single_module_template_part('templates/single/parts/navigation', 'property', $item_layout);
					?>
					
					<div class="mkdf-container">
						<div class="mkdf-container-inner clearfix">
							<?php mkdf_core_get_cpt_single_module_template_part('templates/single/parts/comments', 'property'); ?>
						</div>
					</div>
				<?php } ?>
			</div>
		<?php endwhile; endif; ?>
	</div>
</div>