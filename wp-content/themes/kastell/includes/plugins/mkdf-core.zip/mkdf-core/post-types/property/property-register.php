<?php

namespace MikadoCore\CPT\Property;

use MikadoCore\Lib\PostTypeInterface;

/**
 * Class PropertyRegister
 * @package MikadoCore\CPT\Property
 */
class PropertyRegister implements PostTypeInterface {
	private $base;
	
	public function __construct() {
		$this->base    = 'property-item';
		$this->taxBase = 'property-category';
		
		add_filter( 'archive_template', array( $this, 'registerArchiveTemplate' ) );
		add_filter( 'single_template', array( $this, 'registerSingleTemplate' ) );
	}
	
	/**
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}
	
	/**
	 * Registers custom post type with WordPress
	 */
	public function register() {
		$this->registerPostType();
		$this->registerTax();
		$this->registerTagTax();
	}
	
	/**
	 * Registers property archive template if one does'nt exists in theme.
	 * Hooked to archive_template filter
	 *
	 * @param $archive string current template
	 *
	 * @return string string changed template
	 */
	public function registerArchiveTemplate( $archive ) {
		global $post;
		
		if ( ! empty( $post ) && $post->post_type == $this->base ) {
			if ( ! file_exists( get_template_directory() . '/archive-' . $this->base . '.php' ) ) {
				return MIKADO_CORE_CPT_PATH . '/property/templates/archive-' . $this->base . '.php';
			}
		}
		
		return $archive;
	}
	
	/**
	 * Registers property single template if one does'nt exists in theme.
	 * Hooked to single_template filter
	 *
	 * @param $single string current template
	 *
	 * @return string string changed template
	 */
	public function registerSingleTemplate( $single ) {
		global $post;
		
		if ( ! empty( $post ) && $post->post_type == $this->base ) {
			if ( ! file_exists( get_template_directory() . '/single-property-item.php' ) ) {
				return MIKADO_CORE_CPT_PATH . '/property/templates/single-' . $this->base . '.php';
			}
		}
		
		return $single;
	}
	
	/**
	 * Registers custom post type with WordPress
	 */
	private function registerPostType() {
		$menuPosition = 5;
		$menuIcon     = 'dashicons-screenoptions';
		$slug         = $this->base;
		
		if ( mkdf_core_theme_installed() ) {
			if ( kastell_mkdf_options()->getOptionValue( 'property_single_slug' ) ) {
				$slug = kastell_mkdf_options()->getOptionValue( 'property_single_slug' );
			}
		}
		
		register_post_type( $this->base,
			array(
				'labels'        => array(
					'name'          => esc_html__( 'Mikado Property', 'mkdf-core' ),
					'singular_name' => esc_html__( 'Mikado Property Item', 'mkdf-core' ),
					'add_item'      => esc_html__( 'New Property Item', 'mkdf-core' ),
					'add_new_item'  => esc_html__( 'Add New Property Item', 'mkdf-core' ),
					'edit_item'     => esc_html__( 'Edit Property Item', 'mkdf-core' )
				),
				'public'        => true,
				'has_archive'   => true,
				'rewrite'       => array( 'slug' => $slug ),
				'menu_position' => $menuPosition,
				'show_ui'       => true,
				'supports'      => array(
					'author',
					'title',
					'editor',
					'thumbnail',
					'excerpt',
					'page-attributes',
					'comments'
				),
				'menu_icon'     => $menuIcon
			)
		);
	}
	
	/**
	 * Registers custom taxonomy with WordPress
	 */
	private function registerTax() {
		$labels = array(
			'name'              => esc_html__( 'Property Categories', 'mkdf-core' ),
			'singular_name'     => esc_html__( 'Property Category', 'mkdf-core' ),
			'search_items'      => esc_html__( 'Search Property Categories', 'mkdf-core' ),
			'all_items'         => esc_html__( 'All Property Categories', 'mkdf-core' ),
			'parent_item'       => esc_html__( 'Parent Property Category', 'mkdf-core' ),
			'parent_item_colon' => esc_html__( 'Parent Property Category:', 'mkdf-core' ),
			'edit_item'         => esc_html__( 'Edit Property Category', 'mkdf-core' ),
			'update_item'       => esc_html__( 'Update Property Category', 'mkdf-core' ),
			'add_new_item'      => esc_html__( 'Add New Property Category', 'mkdf-core' ),
			'new_item_name'     => esc_html__( 'New Property Category Name', 'mkdf-core' ),
			'menu_name'         => esc_html__( 'Property Categories', 'mkdf-core' )
		);
		
		register_taxonomy( $this->taxBase, array( $this->base ), array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'property-category' )
		) );
	}
	
	/**
	 * Registers custom tag taxonomy with WordPress
	 */
	private function registerTagTax() {
		$labels = array(
			'name'              => esc_html__( 'Property Tags', 'mkdf-core' ),
			'singular_name'     => esc_html__( 'Property Tag', 'mkdf-core' ),
			'search_items'      => esc_html__( 'Search Property Tags', 'mkdf-core' ),
			'all_items'         => esc_html__( 'All Property Tags', 'mkdf-core' ),
			'parent_item'       => esc_html__( 'Parent Property Tag', 'mkdf-core' ),
			'parent_item_colon' => esc_html__( 'Parent Property Tags:', 'mkdf-core' ),
			'edit_item'         => esc_html__( 'Edit Property Tag', 'mkdf-core' ),
			'update_item'       => esc_html__( 'Update Property Tag', 'mkdf-core' ),
			'add_new_item'      => esc_html__( 'Add New Property Tag', 'mkdf-core' ),
			'new_item_name'     => esc_html__( 'New Property Tag Name', 'mkdf-core' ),
			'menu_name'         => esc_html__( 'Property Tags', 'mkdf-core' )
		);
		
		register_taxonomy( 'property-tag', array( $this->base ), array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'property-tag' )
		) );
	}
}