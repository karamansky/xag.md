<div class="mkdf-property-info-holder">
    <?php
        if($query_results->have_posts()):
            while ( $query_results->have_posts() ) : $query_results->the_post();
    ?>
                <div class="mkdf-property-info-item">
                    <div class="mkdf-pi-main-content">
                        <div class="mkdf-pi-text">
                            <?php echo mkdf_core_get_cpt_shortcode_module_template_part('property', 'property-info', 'parts/title', '', $params); ?>

                            <?php echo mkdf_core_get_cpt_shortcode_module_template_part('property', 'property-info', 'parts/excerpt', '', $params); ?>

                            <?php echo mkdf_core_get_cpt_shortcode_module_template_part('property', 'property-info', 'parts/read-more', '', $params); ?>
                        </div>
                            <?php echo mkdf_core_get_cpt_shortcode_module_template_part('property', 'property-info', 'parts/image', '', $params); ?>
                    </div>
                        <?php echo mkdf_core_get_cpt_shortcode_module_template_part('property', 'property-info', 'parts/feature-slider', '', $params); ?>
                </div>
    <?php
            endwhile;
        else:
            echo mkdf_core_get_cpt_shortcode_module_template_part('property', 'property-info', 'parts/posts-not-found');
        endif;
        wp_reset_postdata();
    ?>
</div>
