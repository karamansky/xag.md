<?php

get_header();

kastell_mkdf_get_title();

do_action('kastell_mkdf_before_main_content');

mkdf_core_get_single_property();

get_footer();