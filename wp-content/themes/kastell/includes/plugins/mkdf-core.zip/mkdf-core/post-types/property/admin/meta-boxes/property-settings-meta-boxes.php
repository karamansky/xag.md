<?php

if ( ! function_exists( 'mkdf_core_map_property_settings_meta' ) ) {
	function mkdf_core_map_property_settings_meta() {
		$meta_box = kastell_mkdf_create_meta_box( array(
			'scope' => 'property-item',
			'title' => esc_html__( 'Property Settings', 'mkdf-core' ),
			'name'  => 'property_settings_meta_box'
		) );

        kastell_mkdf_create_meta_box_field(
            array(
                'name'          => 'mkdf_show_title_area_property_single_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__( 'Show Title Area', 'mkdf-core' ),
                'description'   => esc_html__( 'Enabling this option will show title area on your single property page', 'mkdf-core' ),
                'parent'        => $meta_box,
                'options'       => kastell_mkdf_get_yes_no_select_array()
            )
        );

		
		kastell_mkdf_create_meta_box_field(
			array(
				'name'          => 'mkdf_property_single_item_layout_meta',
				'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__( 'Single Item Layout', 'mkdf-core' ),
                'parent'        => $meta_box,
                'options'       => array(
                    ''                   => esc_html__('Default', 'mkdf-core'),
                    'custom'             => esc_html__( 'Custom', 'mkdf-core' ),
                    'full-width-custom'  => esc_html__( 'Full Width Custom', 'mkdf-core' )
                ),
                'args'          => array(
                    'col_width' => 3
                )
			)
		);
		
		kastell_mkdf_create_meta_box_field(
			array(
				'name'        => 'property_info_top_padding',
				'type'        => 'text',
				'label'       => esc_html__( 'Property Info Top Padding', 'mkdf-core' ),
				'description' => esc_html__( 'Set top padding for property info elements holder. This option works only for Property Images, Slider, Gallery and Masonry property types', 'mkdf-core' ),
				'parent'      => $meta_box,
				'args'        => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);
		
		kastell_mkdf_create_meta_box_field(
			array(
				'name'        => 'property_external_link',
				'type'        => 'text',
				'label'       => esc_html__( 'Property External Link', 'mkdf-core' ),
				'description' => esc_html__( 'Enter URL to link from Property List page', 'mkdf-core' ),
				'parent'      => $meta_box,
				'args'        => array(
					'col_width' => 3
				)
			)
		);
		
		kastell_mkdf_create_meta_box_field(
			array(
				'name'        => 'mkdf_property_featured_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Featured Image', 'mkdf-core' ),
				'description' => esc_html__( 'Choose an image for Property Lists shortcode where Hover Type option is Switch Featured Images', 'mkdf-core' ),
				'parent'      => $meta_box
			)
		);
		
		kastell_mkdf_create_meta_box_field(
			array(
				'name'          => 'mkdf_property_masonry_fixed_dimensions_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Dimensions for Masonry - Image Fixed Proportion', 'mkdf-core' ),
				'description'   => esc_html__( 'Choose image layout when it appears in Masonry type property lists where image proportion is fixed', 'mkdf-core' ),
				'default_value' => 'default',
				'parent'        => $meta_box,
				'options'       => array(
					'default'            => esc_html__( 'Default', 'mkdf-core' ),
					'large-width'        => esc_html__( 'Large Width', 'mkdf-core' ),
					'large-height'       => esc_html__( 'Large Height', 'mkdf-core' ),
					'large-width-height' => esc_html__( 'Large Width/Height', 'mkdf-core' )
				)
			)
		);
		
		kastell_mkdf_create_meta_box_field(
			array(
				'name'          => 'mkdf_property_masonry_original_dimensions_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Dimensions for Masonry - Image Original Proportion', 'mkdf-core' ),
				'description'   => esc_html__( 'Choose image layout when it appears in Masonry type property lists where image proportion is original', 'mkdf-core' ),
				'default_value' => 'default',
				'parent'        => $meta_box,
				'options'       => array(
					'default'     => esc_html__( 'Default', 'mkdf-core' ),
					'large-width' => esc_html__( 'Large Width', 'mkdf-core' )
				)
			)
		);
		
		$all_pages = array();
		$pages     = get_pages();
		foreach ( $pages as $page ) {
			$all_pages[ $page->ID ] = $page->post_title;
		}
		
		kastell_mkdf_create_meta_box_field(
			array(
				'name'        => 'property_single_back_to_link',
				'type'        => 'select',
				'label'       => esc_html__( '"Back To" Link', 'mkdf-core' ),
				'description' => esc_html__( 'Choose "Back To" page to link from property Single Project page', 'mkdf-core' ),
				'parent'      => $meta_box,
				'options'     => $all_pages,
				'args'        => array(
					'select2' => true
				)
			)
		);
	}
	
	add_action( 'kastell_mkdf_meta_boxes_map', 'mkdf_core_map_property_settings_meta', 41 );
}