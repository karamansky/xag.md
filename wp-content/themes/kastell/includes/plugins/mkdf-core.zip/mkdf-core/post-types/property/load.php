<?php

include_once MIKADO_CORE_CPT_PATH . '/property/property-register.php';
include_once MIKADO_CORE_CPT_PATH . '/property/helper-functions.php';