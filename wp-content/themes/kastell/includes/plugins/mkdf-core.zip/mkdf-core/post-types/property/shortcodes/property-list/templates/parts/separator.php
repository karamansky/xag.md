<?php
    if($enable_separator == 'yes') {
        echo kastell_mkdf_execute_shortcode('mkdf_svg_separator', array());
    }