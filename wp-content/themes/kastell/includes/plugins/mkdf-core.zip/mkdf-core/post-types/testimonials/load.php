<?php

include_once MIKADO_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once MIKADO_CORE_CPT_PATH . '/testimonials/helper-functions.php';
include_once MIKADO_CORE_CPT_PATH . '/testimonials/shortcodes/shortcodes-functions.php';