<?php

require_once 'interactive-property-list.php';
require_once 'helper-functions.php';