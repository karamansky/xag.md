(function($) {
    'use strict';

    var interactivePropertyList = {};
    mkdf.modules.interactivePropertyList = interactivePropertyList;

    interactivePropertyList.mkdfOnDocumentReady = mkdfOnDocumentReady;
    interactivePropertyList.mkdfOnWindowLoad = mkdfOnWindowLoad;
    interactivePropertyList.mkdfOnWindowResize = mkdfOnWindowResize;
    interactivePropertyList.mkdfOnWindowScroll = mkdfOnWindowScroll;

    $(document).ready(mkdfOnDocumentReady);
    $(window).on('load', mkdfOnWindowLoad);
    $(window).resize(mkdfOnWindowResize);
    $(window).scroll(mkdfOnWindowScroll);

    /* 
     All functions to be called on $(document).ready() should be in this function
     */
    function mkdfOnDocumentReady() {
        mkdfPropertyFilter();
    }

    /*
     All functions to be called on $(window).on('load', ) should be in this function
     */
    function mkdfOnWindowLoad() {
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function mkdfOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function mkdfOnWindowScroll() {

    }

    function mkdfPropertyFilter() {
        var filterOpener = $('a.mkdf-property-filter-opener');

        if (filterOpener.length > 0) {

            var filterClose = $('.mkdf-property-filter-close'),
                filterHolder = $('.mkdf-property-filter-holder-inner'),
                linkHolder = filterHolder.find('.mkdf-ips-content-table-cell');

            //Init scroll on items holder
            filterHolder.height(mkdf.windowHeight);
            filterHolder.perfectScrollbar({
                wheelPropagation: false,
                minScrollbarLength: 20,
                suppressScrollX: true
            });

            var menuLinkHeight,
                scrollLink,
                wheelAnim,
                goingToScrollTop = filterHolder.scrollTop(),
                items = filterHolder.find('.mkdf-ips-item-content');

            //Calculate height of menu items
            menuLinkHeight = Math.floor(filterHolder.innerHeight() * 0.1);
            items.each(function(){
                $(this).css("height", menuLinkHeight);
            });
            scrollLink = menuLinkHeight;


            //Init font resize function based on position of item
            var menu_scrollMenu = function (event) {
                var screenCenter = filterHolder.innerHeight() * 0.5;
                for (var i = 0; i < items.length; i++) {
                    var $link = $(items[i]);
                    var $text = $link.find("a");
                    var linkCenterPosition = $link.offset().top + $link.innerHeight() * 0.5;
                    var dif = Math.abs(linkCenterPosition - screenCenter);
                    var currentFontSize = filterHolder.innerWidth() * 0.026;
                    // var newFontSize = currentFontSize - dif * 0.1;
                    // if (newFontSize < 50)
                    //     newFontSize = 40;
                    TweenMax.to($text, 0, {
                        "font-size": currentFontSize + "px"
                    });
                }
            };

            menu_scrollMenu();

            //Init recalculation on mouse wheel scroll
            var menu_softScrollWheel = function(event, delta, deltaX, deltaY) {
                event.preventDefault();
                event.stopPropagation();
                if (deltaY < 0) {
                    if(filterHolder.scrollTop() + filterHolder.outerHeight() < linkHolder.outerHeight() ) {
                        goingToScrollTop += scrollLink;
                        wheelAnim = TweenMax.to(filterHolder, 0.5, {
                            scrollTop: goingToScrollTop,
                            ease: Power1.easeOut,
                            onUpdate: function () {
                                wheelAnim.pause();
                                menu_scrollMenu();
                                wheelAnim.resume();
                            }
                        });
                    }
                } else if (deltaY > 0) {
                    if (filterHolder.scrollTop() > 0) {
                        goingToScrollTop -= scrollLink;
                        wheelAnim = TweenMax.to(filterHolder, 0.5, {
                            scrollTop: goingToScrollTop,
                            ease: Power1.easeOut,
                            onUpdate: function () {
                                wheelAnim.pause();
                                menu_scrollMenu();
                                wheelAnim.resume();
                            }
                        });
                    }
                }
                return false;
            };

            filterHolder.mousewheel(menu_softScrollWheel);

            filterOpener.on('click', function (e) {
                e.preventDefault();

                if (filterHolder.hasClass('mkdf-animate')) {
                    mkdf.body.removeClass('mkdf-fullscreen-filter-opened mkdf-filter-fade-out');
                    mkdf.body.removeClass('mkdf-filter-fade-in');
                    filterHolder.removeClass('mkdf-animate');
                    mkdf.modules.common.mkdfEnableScroll();

                } else {
                    mkdf.body.addClass('mkdf-fullscreen-filter-opened mkdf-filter-fade-in');
                    mkdf.body.removeClass('mkdf-filter-fade-out');
                    filterHolder.addClass('mkdf-animate');
                    mkdf.modules.common.mkdfDisableScroll();
                }

                filterClose.on('click', function (e) {
                    e.preventDefault();
                    mkdf.body.removeClass('mkdf-fullscreen-filter-opened mkdf-filter-fade-in');
                    mkdf.body.addClass('mkdf-filter-fade-out');
                    filterHolder.removeClass('mkdf-animate');

                    setTimeout(function () {
                        filterHolder.find('.mkdf-filter-field').val('');
                        filterHolder.find('.mkdf-filter-field').blur();
                    }, 300);

                    mkdf.modules.common.mkdfEnableScroll();
                });

                //Close on escape
                $(document).keyup(function (e) {
                    if (e.keyCode === 27) { //KeyCode for ESC button is 27
                        mkdf.body.removeClass('mkdf-fullscreen-filter-opened mkdf-filter-fade-in');
                        mkdf.body.addClass('mkdf-filter-fade-out');
                        filterHolder.removeClass('mkdf-animate');
                    }
                });
            });
        }

    }

})(jQuery);