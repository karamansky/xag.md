<?php

namespace MikadoCore\CPT\Shortcodes\Property;

use MikadoCore\Lib;

class PropertyInfo implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'mkdf_property_info';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );

		//Property selected projects filter
		add_filter( 'vc_autocomplete_mkdf_property_info_selected_projects_callback', array( &$this, 'propertyIdAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Property selected projects render
		add_filter( 'vc_autocomplete_mkdf_property_info_selected_projects_render', array( &$this, 'propertyIdAutocompleteRender', ), 10, 1 ); // Render exact property. Must return an array (label,value)

	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map( array(
					'name'     => esc_html__( 'Mikado Property Info', 'mkdf-core' ),
					'base'     => $this->getBase(),
					'category' => esc_html__( 'by MIKADO', 'mkdf-core' ),
					'icon'     => 'icon-wpb-property-info extended-custom-icon',
					'params'   => array(
						array(
							'type'        => 'dropdown',
							'param_name'  => 'image_proportions',
							'heading'     => esc_html__( 'Image Proportions', 'mkdf-core' ),
							'value'       => array(
								esc_html__( 'Original', 'mkdf-core' )  => 'full',
								esc_html__( 'Square', 'mkdf-core' )    => 'square',
								esc_html__( 'Landscape', 'mkdf-core' ) => 'landscape',
								esc_html__( 'Portrait', 'mkdf-core' )  => 'portrait',
								esc_html__( 'Medium', 'mkdf-core' )    => 'medium',
								esc_html__( 'Large', 'mkdf-core' )     => 'large',
								esc_html__( 'Huge', 'mkdf-core' )     => 'huge'
							),
							'description' => esc_html__( 'Set image proportions for your property list.', 'mkdf-core' ),
							'dependency'  => array( 'element' => 'type', 'value' => array( 'gallery' ) )
						),
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'selected_projects',
							'heading'     => esc_html__( 'Show Project with Listed ID', 'mkdf-core' ),
							'settings'    => array(
								'multiple'      => false,
								'sortable'      => true,
								'unique_values' => true
							),
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'enable_title',
							'heading'    => esc_html__( 'Enable Title', 'mkdf-core' ),
							'value'      => array_flip( kastell_mkdf_get_yes_no_select_array( false, true ) ),
							'group'      => esc_html__( 'Content Layout', 'mkdf-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'title_tag',
							'heading'    => esc_html__( 'Title Tag', 'mkdf-core' ),
							'value'      => array_flip( kastell_mkdf_get_title_tag( true ) ),
							'dependency' => array( 'element' => 'enable_title', 'value' => array( 'yes' ) ),
							'group'      => esc_html__( 'Content Layout', 'mkdf-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'title_text_transform',
							'heading'    => esc_html__( 'Title Text Transform', 'mkdf-core' ),
							'value'      => array_flip( kastell_mkdf_get_text_transform_array( true ) ),
							'dependency' => array( 'element' => 'enable_title', 'value' => array( 'yes' ) ),
							'group'      => esc_html__( 'Content Layout', 'mkdf-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'enable_category',
							'heading'    => esc_html__( 'Enable Category', 'mkdf-core' ),
							'value'      => array_flip( kastell_mkdf_get_yes_no_select_array( false, true ) ),
							'group'      => esc_html__( 'Content Layout', 'mkdf-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'enable_excerpt',
							'heading'    => esc_html__( 'Enable Excerpt', 'mkdf-core' ),
							'value'      => array_flip( kastell_mkdf_get_yes_no_select_array( false ) ),
							'group'      => esc_html__( 'Content Layout', 'mkdf-core' )
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'excerpt_length',
							'heading'     => esc_html__( 'Excerpt Length', 'mkdf-core' ),
							'description' => esc_html__( 'Number of characters', 'mkdf-core' ),
							'dependency'  => array( 'element' => 'enable_excerpt', 'value' => array( 'yes' ) ),
							'group'       => esc_html__( 'Content Layout', 'mkdf-core' )
						)
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'image_proportions'        => 'full',
			'selected_projects'        => '',
			'enable_title'             => 'yes',
			'title_tag'                => 'h1',
			'title_text_transform'     => '',
			'enable_category'          => 'yes',
			'enable_excerpt'           => 'no',
			'excerpt_length'           => '100'
		);
		$params = shortcode_atts( $args, $atts );
		
		/***
		 * @params query_results
		 * @params holder_data
		 * @params holder_classes
		 * @params holder_inner_classes
		 */
		$additional_params = array();
		
		$query_array                        = $this->getQueryArray( $params );
		$query_results                      = new \WP_Query( $query_array );
		$additional_params['query_results'] = $query_results;
		
		$additional_params['holder_data']          = $this->getHolderData( $params, $additional_params );
		$additional_params['holder_classes']       = $this->getHolderClasses( $params, $args );
		$additional_params['holder_inner_classes'] = $this->getHolderInnerClasses( $params );
		
		$params['this_object'] = $this;
		
		$html = mkdf_core_get_cpt_shortcode_module_template_part( 'property', 'property-info', 'property-info', '', $params, $additional_params );
		
		return $html;
	}
	
	public function getQueryArray( $params ) {
		$query_array = array(
			'post_status'    => 'publish',
			'post_type'      => 'property-item',
		);

		
		$project_ids = null;
		if ( ! empty( $params['selected_projects'] ) ) {
			$project_ids             = explode( ',', $params['selected_projects'] );
			$query_array['post__in'] = $project_ids;
		}

        $query_array['paged'] = 1;

		return $query_array;
	}
	
	public function getHolderData( $params, $additional_params ) {
		$dataString = '';
		
		if ( get_query_var( 'paged' ) ) {
			$paged = get_query_var( 'paged' );
		} elseif ( get_query_var( 'page' ) ) {
			$paged = get_query_var( 'page' );
		} else {
			$paged = 1;
		}
		
		$query_results           = $additional_params['query_results'];
		$params['max_num_pages'] = $query_results->max_num_pages;
		
		if ( ! empty( $paged ) ) {
			$params['next_page'] = $paged + 1;
		}
		
		foreach ( $params as $key => $value ) {
			if ( $value !== '' ) {
				$new_key = str_replace( '_', '-', $key );
				
				$dataString .= ' data-' . $new_key . '=' . esc_attr( $value );
			}
		}
		
		return $dataString;
	}
	
	public function getHolderClasses( $params, $args ) {
		$classes = array();

		
		return implode( ' ', $classes );
	}
	
	public function getHolderInnerClasses( $params ) {
		$classes = array();

		return implode( ' ', $classes );
	}
	
	public function getImageSize( $params ) {
		$thumb_size = 'full';
		
		if ( ! empty( $params['image_proportions'] ) ) {
			$image_size = $params['image_proportions'];
			
			switch ( $image_size ) {
				case 'landscape':
					$thumb_size = 'kastell_mkdf_landscape';
					break;
				case 'portrait':
					$thumb_size = 'kastell_mkdf_portrait';
					break;
				case 'square':
					$thumb_size = 'kastell_mkdf_square';
					break;
                case 'huge':
					$thumb_size = 'kastell_mkdf_huge';
					break;
				case 'medium':
					$thumb_size = 'medium';
					break;
				case 'large':
					$thumb_size = 'large';
					break;
				case 'full':
					$thumb_size = 'full';
					break;
			}
		}
		
		return $thumb_size;
	}
	
	public function getTitleStyles( $params ) {
		$styles = array();
		
		if ( ! empty( $params['title_text_transform'] ) ) {
			$styles[] = 'text-transform: ' . $params['title_text_transform'];
		}
		
		return implode( ';', $styles );
	}
	
	/**
	 * Filter propertys by ID or Title
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function propertyIdAutocompleteSuggester( $query ) {
		global $wpdb;
		$property_id    = (int) $query;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT ID AS id, post_title AS title
					FROM {$wpdb->posts} 
					WHERE post_type = 'property-item' AND ( ID = '%d' OR post_title LIKE '%%%s%%' )", $property_id > 0 ? $property_id : - 1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );
		
		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['id'];
				$data['label'] = esc_html__( 'Id', 'mkdf-core' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . esc_html__( 'Title', 'mkdf-core' ) . ': ' . $value['title'] : '' );
				$results[]     = $data;
			}
		}
		
		return $results;
	}
	
	/**
	 * Find property by id
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function propertyIdAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get property
			$property = get_post( (int) $query );
			if ( ! is_wp_error( $property ) ) {
				
				$property_id    = $property->ID;
				$property_title = $property->post_title;
				
				$property_title_display = '';
				if ( ! empty( $property_title ) ) {
					$property_title_display = ' - ' . esc_html__( 'Title', 'mkdf-core' ) . ': ' . $property_title;
				}
				
				$property_id_display = esc_html__( 'Id', 'mkdf-core' ) . ': ' . $property_id;
				
				$data          = array();
				$data['value'] = $property_id;
				$data['label'] = $property_id_display . $property_title_display;
				
				return ! empty( $data ) ? $data : false;
			}
			
			return false;
		}
		
		return false;
	}

}