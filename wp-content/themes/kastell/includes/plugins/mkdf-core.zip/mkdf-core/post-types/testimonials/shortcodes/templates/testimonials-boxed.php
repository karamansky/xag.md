<div class="mkdf-testimonial-content" id="mkdf-testimonials-<?php echo esc_attr( $current_id ) ?>" >
	<?php if ( has_post_thumbnail() || ! empty( $author ) ) { ?>
		<div class="mkdf-testimonials-author-image-holder clearfix">
			<?php if ( has_post_thumbnail() ) { ?>
				<div class="mkdf-testimonial-image">
					<?php echo get_the_post_thumbnail( get_the_ID(), array( 80, 80 ) ); ?>
				</div>
			<?php } ?>
		</div>
	<?php } ?>
	<div class="mkdf-testimonial-text-holder" <?php kastell_mkdf_inline_style( $box_styles ); ?>>
		<?php if ( ! empty( $text ) ) { ?>
			<p class="mkdf-testimonial-text"><?php echo esc_html( $text ); ?></p>
		<?php } ?>
		<?php if ( ! empty( $author ) ) { ?>
			<div class="mkdf-testimonial-author">
				<div class="mkdf-testimonials-author-name"><?php echo esc_html( $author ); ?></div>
				<?php if ( ! empty( $position ) ) { ?>
					<div class="mkdf-testimonials-author-job"><?php echo esc_html( $position ); ?></div>
				<?php } ?>
			</div>
		<?php } ?>
	</div>
</div>