(function($) {
    'use strict';

    var propertyInfo = {};
    mkdf.modules.propertyInfo = propertyInfo;

    propertyInfo.mkdfOnDocumentReady = mkdfOnDocumentReady;
    propertyInfo.mkdfOnWindowLoad = mkdfOnWindowLoad;
    propertyInfo.mkdfOnWindowResize = mkdfOnWindowResize;
    propertyInfo.mkdfOnWindowScroll = mkdfOnWindowScroll;

    $(document).ready(mkdfOnDocumentReady);
    $(window).on('load', mkdfOnWindowLoad);
    $(window).resize(mkdfOnWindowResize);
    $(window).scroll(mkdfOnWindowScroll);

    /* 
     All functions to be called on $(document).ready() should be in this function
     */
    function mkdfOnDocumentReady() {

    }

    /*
     All functions to be called on $(window).on('load', ) should be in this function
     */
    function mkdfOnWindowLoad() {
        mkdfPropertyInfo();
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function mkdfOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function mkdfOnWindowScroll() {

    }

    var mkdfPropertyInfo = function() {
        var Infos = $('.mkdf-pi-feature-slider');
        Infos.each(function () {

            var slider = $(this);
            var slideItemsNumber = slider.children().length;

            var loop = true,
                autoplay = false,
                sliderSpeed = 5000,
                numberOfItems = 3,
                margin= 30,
                navigation = true,
                pagination = false;

            if (slideItemsNumber <= 1) {
                loop       = false;
                autoplay   = false;
                navigation = false;
                pagination = false;
            }

            var responsiveNumberOfItems1 = 1,
                responsiveNumberOfItems2 = 2,
                responsiveNumberOfItems3 = 3,
                responsiveNumberOfItems4 = numberOfItems;

            if (numberOfItems < 3) {
                responsiveNumberOfItems2 = numberOfItems;
                responsiveNumberOfItems3 = numberOfItems;
            }

            if (numberOfItems > 4) {
                responsiveNumberOfItems4 = 4;
            }

            slider.owlCarousel({
                items: numberOfItems,
                loop: loop,
                autoplay: autoplay,
                autoplayHoverPause: false,
                autoplayTimeout: sliderSpeed,
                smartSpeed: 500,
                margin: margin,
                autoWidth: false,
                animateIn: false,
                animateOut: false,
                dots: false,
                nav: navigation,
                navText: [
                    '<span class="mkdf-prev-icon ion-ios-arrow-left"></span>',
                    '<span class="mkdf-next-icon ion-ios-arrow-right"></span>'
                ],
                responsive: {
                    0: {
                        items: responsiveNumberOfItems1,
                        stagePadding: 0,
                        center: false,
                        autoWidth: false
                    },
                    681: {
                        items: responsiveNumberOfItems2,
                    },
                    769: {
                        items: responsiveNumberOfItems3,
                    },
                    1025: {
                        items: responsiveNumberOfItems4
                    },
                    1281: {
                        items: numberOfItems
                    }
                },
                onInitialize: function () {
                    slider.css('visibility', 'visible');
                    // mkdfInitParallax();
                },
                onDrag: function (e) {
                    if (mkdf.body.hasClass('mkdf-smooth-page-transitions-fadeout')) {
                        var sliderIsMoving = e.isTrigger > 0;

                        if (sliderIsMoving) {
                            slider.addClass('mkdf-slider-is-moving');
                        }
                    }
                },
                onDragged: function () {
                    if (mkdf.body.hasClass('mkdf-smooth-page-transitions-fadeout') && slider.hasClass('mkdf-slider-is-moving')) {

                        setTimeout(function () {
                            slider.removeClass('mkdf-slider-is-moving');
                        }, 500);
                    }
                }
            });
        })
    };


})(jQuery);