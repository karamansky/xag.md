<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/simple-quote/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/simple-quote/simple-quote.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/simple-quote/custom-styles/custom-styles.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/simple-quote/options-map/map.php';