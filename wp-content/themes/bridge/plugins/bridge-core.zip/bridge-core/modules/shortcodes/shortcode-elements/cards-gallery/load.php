<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/cards-gallery/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/cards-gallery/cards-gallery.php';