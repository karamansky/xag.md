<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/elliptical-slider/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/elliptical-slider/elliptical-slider.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/elliptical-slider/elliptical-slide.php';