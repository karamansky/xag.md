<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/interest-rate-calculator/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/interest-rate-calculator/interest-rate-calculator.php';