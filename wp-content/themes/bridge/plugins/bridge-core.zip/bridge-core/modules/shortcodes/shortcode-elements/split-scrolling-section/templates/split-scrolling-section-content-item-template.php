<div class="qode-sss-ms-section" <?php echo bridge_qode_get_inline_attrs($content_data); ?> <?php bridge_qode_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>