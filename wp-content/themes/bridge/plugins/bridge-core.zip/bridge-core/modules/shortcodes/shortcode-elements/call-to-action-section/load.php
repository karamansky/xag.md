<?php
include_once BRIDGE_CORE_SHORTCODES_PATH.'/call-to-action-section/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/call-to-action-section/call-to-action-section.php';