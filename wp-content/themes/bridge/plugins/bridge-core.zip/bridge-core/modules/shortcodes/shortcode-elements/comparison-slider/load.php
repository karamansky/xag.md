<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/comparison-slider/cmp-slider.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/comparison-slider/functions.php';