<div class="qode_vertical_separator" <?php bridge_qode_inline_style($holder_style); ?>>
</div>