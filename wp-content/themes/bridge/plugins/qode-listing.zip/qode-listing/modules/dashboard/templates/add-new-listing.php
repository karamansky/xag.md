<div class="qode-membership-dashboard-page">
	<div class="qode-membership-dashboard-page-content">
		<?php
			echo bridge_qode_execute_shortcode('submit_job_form', '');
		?>
	</div>
</div>