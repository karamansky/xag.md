<div class="qode-instructor-single-content">
	<?php the_content(); ?>
</div>